from odoo import http
from odoo.http import request


class dashPortal(http.Controller):

    @http.route('/helloworld', type='http', auth='public', website=True)
    def dash_template(self, **kwargs):
        # Render your template
        return request.render('looker_dashboard.dash_template', {})

{
    'name': 'Looker Studio Dashbaord',
    'author': 'Ibees',
    'website': 'https://www.facebook.com',
    'summary': 'Odoo 17 dashboard module in progress',
    'category': 'ibees',
    'license': 'AGPL-3',
    'depends': ['website'],
    'data': [
        "views/dash.xml",
        ],
    "installable": True,
    "application": True,
}

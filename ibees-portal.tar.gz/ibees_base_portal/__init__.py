# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import controllers
from . import models
from . import wizard

from odoo import api, SUPERUSER_ID


def uninstall_hook(cr, registry):
    env = api.Environment(cr, SUPERUSER_ID, {})
    ICP = env["ir.config_parameter"]
    ICP.set_param("ibees_sem_google.custom_search.key", False)
    ICP.set_param("ibees_sem_google.pse.id", False)
    ICP.set_param("ibees_sem_proxy.url.id", False)

# pylint: skip-file
{
    "name": "iBees Customer Portal",
    "summary": """Website Customer Portal""",
    "author": "iBees",
    "website": "http://www.ibees.biz",
    # Categories can be used to filter modules in modules listing
    # for the full list
    "category": "iBees/Portal",
    "version": "17.0.1.0.0",
    "license": "AGPL-3",
    # any module necessary for this one to work correctly
    "depends": [
        "base",
        "portal",
        "account",
        "mail",
        "crm",
    ],
    # always loaded
    "data": [
        "security/ir.model.access.csv",
        "views/layout_vertical_template.xml",
        "views/inherit_portal_dash_templates.xml",
        "views/inherit_portal_my_crm.xml",
        "views/sales_order.xml",
        "views/portal_invoices.xml",
        "views/portal_help_desk.xml",
        "views/portal_form_detials.xml",
        "views/portal_security.xml",
        "views/main_invoice.xml",
        "views/order_main.xml",
        "views/portal_contact_us.xml",
        "views/rfq_main.xml",
        "views/request_for_quotation.xml",
        "views/chatter.xml",
        "views/account.xml",
    ],
    "external_dependencies": {
    },
    "assets": {
        "web.assets_frontend": [
            'ibees_base_portal/static/src/fonts/inter/inter.css',
            'ibees_base_portal/static/src/fonts/tabler-icons.min.css',
            'ibees_base_portal/static/src/fonts/feather.css',
            'ibees_base_portal/static/src/fonts/fontawesome.css',
            'ibees_base_portal/static/src/fonts/material.css',
            # 'ibees_base_portal/static/src/scss/landing.css',
            'ibees_base_portal/static/src/scss/custom_style.css',
            'ibees_base_portal/static/src/scss/style.css',
            # 'ibees_base_portal/static/src/scss/style-preset.css',
            # '../ibees_base_portal/static/src/js/title.js',
            # 'ibees_base_portal/static/src/images/**/*',
            # 'ibees_base_portal/static/src/js/plugins/bootstrap.min.js',
            'ibees_base_portal/static/src/js/fonts/custom-font.js',

            'ibees_base_portal/static/src/js/plugins/apexcharts.min.js',
            'ibees_base_portal/static/src/js/pages/dashboard-default.js',
            'ibees_base_portal/static/src/js/plugins/popper.min.js',
            'ibees_base_portal/static/src/js/plugins/simplebar.min.js',
            # 'ibees_base_portal/static/src/js/plugins/bootstrap.min.js',
            'ibees_base_portal/static/src/js/pcoded.js',
            'ibees_base_portal/static/src/js/control_sidebar.js',
            'ibees_base_portal/static/src/js/plugins/feather.min.js',
            'ibees_base_portal/static/src/js/layout-compact.js',
        ],
    },
    # only loaded in demonstration mode
    "installable": True,
    "application": True,
}

$(document).ready(function() {
var chatter = new ChatterWidget({
model: 'your.custom.model',
res_id: your_record_id,
element: '#chatter_widget',
domain: [],
context: {}
});
chatter.appendTo($('#chatter_widget'));
});

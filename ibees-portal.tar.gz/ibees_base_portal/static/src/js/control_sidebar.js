// Menu collapse click start
  var mobile_collapse_over = document.querySelector('#mobile-collapse');
  if (mobile_collapse_over) {
    mobile_collapse_over.addEventListener('click', function () {
      var temp_sidebar = document.querySelector('.pc-sidebar');
      if (temp_sidebar) {
        if (document.querySelector('.pc-sidebar').classList.contains('mob-sidebar-active')) {
          rm_menu();
        } else {
          document.querySelector('.pc-sidebar').classList.add('mob-sidebar-active');
          document.querySelector('.pc-sidebar').insertAdjacentHTML('beforeend', '<div class="pc-menu-overlay"></div>');
          document.querySelector('.pc-menu-overlay').addEventListener('click', function () {
            rm_menu();
          });
        }
      }
    });
  }
  // Menu collapse click end

var sidebar_hide = document.querySelector('#sidebar-hide');
  if (sidebar_hide) {
    sidebar_hide.addEventListener('click', function () {
      if (document.querySelector('.pc-sidebar').classList.contains('pc-sidebar-hide')) {
        document.querySelector('.pc-sidebar').classList.remove('pc-sidebar-hide');
      } else {
        document.querySelector('.pc-sidebar').classList.add('pc-sidebar-hide');
      }
    });
  }

function goToPage(page) {
  // Implement logic to navigate to the specified page
  if (page === 'home') {
    window.location.href = '/my/test'; // Replace 'home.html' with the actual URL of your home page
    }
  else if( page === 'rfq'){
    window.location.href = '/my/crm-rfqs';
  }
  else if( page === 'sale'){
    window.location.href = '/my/quote';
  }
  else if( page === 'invoice'){
    window.location.href = '/my/invoices';
  }else {
    // For other pages, you can handle navigation accordingly
    // For example:
    // window.location.href = page + '.html';
    console.log('Navigating to', page);
  }
}


 $(document).ready(function(){
            $("#submitButton").click(function(){
                // Perform AJAX form submission
                $.ajax({
                    url: "/quotation_form",
                    type: "POST",
                    data: $("#quotation_form").serialize(),
                    success: function(response){
                         if (response === 'true'){
                            // On successful submission, display the success message
                            $("#successMessage").show();
                        } else {
                            // If the response doesn't contain the success message, handle the error
                            console.error("Error: Record creation failed");
                        }
                    }
                });
            });
        });

// $(document).ready(function(){
//            $("#contactus_submit").click(function(){
//                // Perform AJAX form submission
//                $.ajax({
//                    url: "/website_form_submit",
//                    type: "POST",
//                    data: $("#website_form_submit").serialize(),
//                    success: function(response){
//                         if (response === 'true'){
//                            // On successful submission, display the success message
//                            $("#successMessage_contactus").show();
//                        } else {
//                            // If the response doesn't contain the success message, handle the error
//                            console.error("Error: Record creation failed");
//                        }
//                    }
//                });
//            });
//        });


// function submitAndClearForm() {
//        document.getElementById("contactus_form").reset();
//        }


    function submitAndClearForm() {
        // Check if all required fields are filled
        var name = document.getElementById("contact1").value;
        var email = document.getElementById("contact3").value;
        var subject = document.getElementById("contact5").value;
        var question = document.getElementById("contact6").value;

        var isValid = true;

        if (name.trim() === "") {
            displayError("contact1", "Please enter your name.");
            isValid = false;
        } else {
            hideError("contact1");
        }

        if (email.trim() === "") {
            displayError("contact3", "Please enter your email.");
            isValid = false;
        } else {
            hideError("contact3");
        }

        if (subject.trim() === "") {
            displayError("contact5", "Please enter the subject.");
            isValid = false;
        } else {
            hideError("contact5");
        }

        if (question.trim() === "") {
            displayError("contact6", "Please enter your question.");
            isValid = false;
        } else {
            hideError("contact6");
        }

        if (isValid) {
            var formData = new FormData(document.getElementById("contactus_form"));
            // Submit the form data using AJAX
            $.ajax({
                type: "POST",
                url: "/website_form_submit", // Change the URL to your controller's URL
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    // Clear the form fields
                    document.getElementById("contactus_form").reset();
                    // Show success message
                    document.getElementById("successMessage_contactus").style.display = "block";
                },
                error: function(xhr, status, error) {
                    // Handle error if AJAX request fails
                    alert("Error: " + error);
                }
            });
        }

        return false; // Prevent default form submission
    }

    function displayError(fieldId, message) {
        var errorDiv = document.getElementById(fieldId + "_error");
        if (errorDiv === null) {
            errorDiv = document.createElement("div");
            errorDiv.id = fieldId + "_error";
            errorDiv.className = "error-message";
            var fieldElement = document.getElementById(fieldId);
            fieldElement.parentNode.insertBefore(errorDiv, fieldElement.nextSibling);
        }
        errorDiv.innerHTML = message;
    }

    function hideError(fieldId) {
        var errorDiv = document.getElementById(fieldId + "_error");
        if (errorDiv !== null) {
            errorDiv.parentNode.removeChild(errorDiv);
        }
    }

// $(document).ready(function(){
//    $("#submitButton").click(function(){
//        // Perform AJAX form submission
//        $.ajax({
//            url: "/quotation_form",
//            type: "POST",
//            data: $("#quotation_form").serialize(),
//            success: function(response){
//                // On successful submission, display the success message
//                $("#successMessage").show();
//
//                // Now, let's handle storing form data into the crm.lead model
//                // Extract form data
//                var formData = $("#quotation_form").serializeArray();
//
//                // Create an object to hold the form data
//                var crmData = {};
//                $(formData).each(function(index, obj){
//                    crmData[obj.name] = obj.value;
//                });
//
//                // Send AJAX request to store data in the crm.lead model
//                $.ajax({
//                    url: "/store-crm-lead-data",
//                    type: "POST",
//                    data: crmData,
//                    success: function(response){
//                        // Log success message (you can handle it according to your needs)
//                        console.log("Data stored in crm.lead model successfully:", response);
//                    },
//                    error: function(xhr, status, error){
//                        // Log error message (you can handle it according to your needs)
//                        console.error("Error storing data in crm.lead model:", error);
//                    }
//                });
//            }
//        });
//    });
//});

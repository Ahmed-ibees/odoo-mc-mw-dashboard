from odoo import models, api, fields


class MyModel(models.Model):
    _name = 'custom.login'

    flag = fields.Selection([
        ('home', 'Home'),
        ('rfq', 'RFQ'),
        ('sale', 'Sale Order'),
        ('invoice', 'Invoices'),
        ('account', 'Account Information'),
        ('login', 'Login & Security'),
    ], string='pages heading', default='home')

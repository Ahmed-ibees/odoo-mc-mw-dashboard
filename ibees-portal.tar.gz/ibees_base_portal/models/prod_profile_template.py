import hashlib

from odoo import api, fields, models

# from odoo.addons.http_routing.models.ir_http import slug


class ProductTemplate(models.Model):

    _inherit = "product.template"

    # Schema fields
    schema_sameAs = fields.Char(
        string="Schema-sameAs (Wikipedia/data page url)",
        default="https://en.wikipedia.org/wiki/Cardboard_box",
        help="URL of a reference Web page that unambiguously indicates the item's \
        identity. E.g. the URL of the item's \
        Wikipedia page, Wikidata entry, or official website.",
    )

    out_sell = fields.Boolean("B2B", default=True, help="Product for B2B")

    ib_prod_shape_type = fields.Selection(
        [
            ("box", "Box"),
            ("bag", "Bag"),
            ("cylinder", "Cylinder"),
            ("pyramid", "Pyramid"),
        ],
        default="box",
        string="Shape Type",
    )

    ib_prod_3d = fields.Boolean(
        "3D Ready?", default=True, help="Check if this product is ready for 3D design"
    )

    ib_profile_temp_id = fields.Many2many(
        "prod.profile.tmpl", string="Product Profile Template"
    )

    # def _compute_website_url(self):
    #     super(ProductTemplate, self)._compute_website_url()
    #     for product in self:
    #         if product.id and product.destination:
    #             product.website_url = product.destination
    #         elif product.id:
    #             product.website_url = "/shop/%s" % slug(product)

    @api.model
    def image_url_responsive(self, record, field, img_type=None, size=None):
        """Returns a local url"""
        sudo_record = record.sudo()
        sha = hashlib.sha512(
            str(getattr(sudo_record, "__last_update")).encode("utf-8")
        ).hexdigest()[:7]
        size = "" if size is None else "/%s" % size
        url = ""

        if img_type == "avif":
            url = "/avif/image/%s/%s/%s%s?unique=%s" % (
                record._name,
                record.id,
                field,
                size,
                sha,
            )

        elif img_type == "webp":
            url = "/webp/image/%s/%s/%s%s?unique=%s" % (
                record._name,
                record.id,
                field,
                size,
                sha,
            )

        elif img_type == "default":
            url = "/web/image/%s/%s/%s%s?unique=%s" % (
                record._name,
                record.id,
                field,
                size,
                sha,
            )

        return url


class ProducProfileTemp(models.Model):
    _name = "prod.profile.tmpl"
    _description = "Product Profile Template"

    name = fields.Char(string="Product Profile Template")

    # Just keep many2many simple do not add relation= or any other extra
    ib_prod_style_ids = fields.Many2many("prod.style", string="Styles")

    ibees_prod_addons_ids = fields.Many2many("prod.addons", string="Addons")

    ibees_prod_stock_ids = fields.Many2many("prod.stock", string="Stock")

    ibees_prod_color_ids = fields.Many2many("prod.color", string="Printing Color")

    ibees_prod_finish_ids = fields.Many2many("prod.finish", string="Finishing")


class ProductStyle(models.Model):
    _name = "prod.style"
    _description = "Product Style"

    name = fields.Char(string="Product Style Names")
    ib_prod_style_ids = fields.Many2many("prod.profile.tmpl", string="Product")


class ProductStock(models.Model):
    _name = "prod.stock"
    _description = "Product Stock"

    name = fields.Char(string="Product Stock")
    ibees_prod_stock_ids = fields.Many2many("prod.profile.tmpl", string="Product")


class ProductAddons(models.Model):
    _name = "prod.addons"
    _description = "Card Box Addons"

    name = fields.Char(string="Add-on Name")
    ibees_prod_addons_ids = fields.Many2many("prod.profile.tmpl", string="Product")


class ProductColors(models.Model):
    _name = "prod.color"
    _description = "Printing Color"

    name = fields.Char(string="Printing Color", required=True)
    ibees_prod_color_ids = fields.Many2many("prod.profile.tmpl", string="Product")



class ProductFinish(models.Model):
    _name = "prod.finish"
    _description = "Finish"

    name = fields.Char(string="Finish")
    ibees_prod_finish_ids = fields.Many2many("prod.profile.tmpl", string="Product")

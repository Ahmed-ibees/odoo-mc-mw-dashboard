from odoo import models, api, fields


class CustomModel(models.Model):
    _name = 'portal.sales'  # Replace 'custom.model' with your model name
    _inherit = ['mail.thread', 'mail.activity.mixin']
    # Add necessary fields here, such as message_follower_ids and message_ids
    message_follower_ids = fields.Many2many('res.partner', string="Followers")
    message_ids = fields.One2many('mail.message', 'res_id', string="Messages")

    @api.model
    def fetch_sale_orders(self):
        # Use Odoo's ORM methods to fetch sale orders
        sale_orders = self.env['sale.order'].search([])  # Fetch all sale orders
        # Now you can use the fetched sale orders as needed
        for order in sale_orders:
            print(order.name)  # Example: Print the name of each sale order
        return sale_orders  # Optionally return the fetched sale orders

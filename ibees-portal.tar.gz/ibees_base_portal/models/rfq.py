from odoo import models, fields


# from datetime import datetime, timedelta

class rfq_fields(models.Model):
    _inherit = 'crm.lead'

    ibees_crm_lead_source = fields.Char(
        string="Lead source",
        readonly=True,
        help="Source of the lead. E.g. website page link.",
    )

    ibees_crm_lead_cta = fields.Char(
        string="Lead source CTA",
        readonly=False,
        help="Source of the lead. E.g.Call to action",
    )

    ibees_source_ip = fields.Char(
        string="Lead source IP",
        readonly=True,
        help="Source IP",
    )
    # Quote form fields
    ibees_crm_size_length = fields.Char(
        string="Box Length",
        tracking=True,
        copy=True,
        store=True,
        index=False,
        help=" Box Length in inches ",
    )

    ibees_crm_size_height = fields.Char(
        string="Box Height",
        tracking=True,
        copy=True,
        store=True,
        index=False,
        help=" Box Height in inches ",
    )

    ibees_crm_size_width = fields.Char(
        string="Box Width",
        tracking=True,
        copy=True,
        store=True,
        index=False,
        help=" Box Width in inches ",
    )

    ibees_crm_size_unit = fields.Selection(
        [("_inch", "inch"), ("_cm", "cm"), ("_mm", "mm")],
        string="Size Unit",
        store=True,
        index=False,
        tracking=True,
    )

    ibees_crm_quantity = fields.Char(
        string="Quantity",
        tracking=True,
        copy=True,
        store=True,
        index=False,
        help="Comma seperated in case of multiple quantities",
    )

    ibees_crm_printing = fields.Char(
        string="Printing Type",
        tracking=True,
        copy=True,
        store=True,
        index=False,
        help="Offset,Digital ete.",
    )

    ibees_crm_finish_other = fields.Char(
        string="Other Finishing",
        tracking=True,
        copy=True,
        store=True,
        index=False,
        help="Other Finishing",
    )

    ibees_crm_sample = fields.Selection(
        [
            ("_none", "None"),
            ("_free", "Free Sample Kit"),
            ("_custom", "Custom Sample"),
        ],
        string="Sample",
        tracking=True,
        copy=True,
        store=True,
        index=False,
        help="Sample",
    )

    ibees_crm_notepce = fields.Text(
        string="Customer's Special Instructions",
        tracking=True,
        copy=True,
        store=True,
        index=False,
    )
    ibees_crm_date = fields.Datetime(
        string="Approx. Target Delivery Date/Time",
        readonly=False,
        tracking=True,
        copy=True,
        help="Approx. Target order delivery date",
    )

    ibees_crm_sku = fields.Char(string="No. of SKUs")

    rfq_geo_city = fields.Char(string="RFQ GEO City", readonly=True)

    rfq_geo_state = fields.Char(string="RFQ GEO State", readonly=True)

    rfq_geo_country = fields.Char(string="RFQ GEO Country", readonly=True)

    ibees_prod_addons = fields.Many2many("prod.addons", string="Addons")

    ib_prod_style = fields.Many2one("prod.style", string="Product Style")

    ibees_prod_stock = fields.Many2one("prod.stock", string="Stock")

    ibees_prod_color_id = fields.Many2one("prod.color", string="Printing Color")

    ibees_prod_finish = fields.Many2one("prod.finish", string="Finishing")

    ibees_product_id = fields.Many2one("product.template", string="Product")

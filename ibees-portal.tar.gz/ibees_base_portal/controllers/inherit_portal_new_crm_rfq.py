from odoo import http
from odoo.http import request


class PortalNewRfq(http.Controller):
    @http.route(["/my/new-crm-rfq"], type="http", auth="public", website=True)
    def rfqPage(self):

        values = {
            "product_list": request.env["product.template"]
            .sudo()
            .search(
                [],
                order="name asc",  # noqa: B950
            ),
            "prod_colors": request.env["prod.color"]
            .sudo()
            .search(
                [],
                order="id asc",  # noqa: B950
            ),
            "prod_stocks": request.env["prod.stock"]
            .sudo()
            .search(
                [],
                order="id asc",  # noqa: B950
            ),
            "prod_styles": request.env["prod.style"]
            .sudo()
            .search(
                [],
                order="id asc",  # noqa: B950
            ),
            "prod_finishes": request.env["prod.finish"]
            .sudo()
            .search(
                [],
                order="id asc",  # noqa: B950
            ),
            "prod_addons": request.env["prod.addons"]
            .sudo()
            .search(
                [],
                order="id asc",  # noqa: B950
            ),
            # "stages": request.env["crm.stage"].search(
            #     [("is_won", "!=", True), ("is_external_stage", "!=", False)],
            #     order="sequence desc, name desc, id desc",  # noqa: B950
            # ),
            "stages": request.env["crm.stage"].search(
                # [("is_won", "!=", True), ("is_external_stage", "!=", False)],
                [("is_won", "!=", True)],
                order="sequence desc, name desc, id desc",  # noqa: B950
            ),
        }

        return request.render("ibees_base_portal.rfq_quotations", values)
        # return request.render("ibees_base_portal.portal_new_rfq", values)

    @http.route(['/quotation_form'], type='http', auth="public", website=True, csrf=False)
    def form_submit(self, **post):
        current_user = request.env.user
        use_lead = request.env['ir.config_parameter'].sudo().get_param('group_use_lead')
        lead_type = 'lead' if use_lead == 'True' else 'opportunity'
        if current_user and current_user.partner_id:
            name_u = current_user.partner_id.name
        else:
            name_u = post.get('contact_name')
        crm = {
            'ibees_product_id': post.get('ibees_product_id'),
            'ibees_crm_size_length': post.get('ibees_crm_size_length'),
            'ibees_crm_size_width': post.get('ibees_crm_size_width'),
            'ibees_crm_size_height': post.get('ibees_crm_size_height'),
            'ibees_crm_size_unit': post.get('ibees_crm_size_unit'),
            'ibees_prod_color_id': post.get('lsi6qc4sv3kkcolor'),
            'ibees_prod_stock': post.get('ibees_prod_color_id'),
            'ib_prod_style': post.get('ib_prod_style'),
            'ibees_prod_finish': post.get('ibees_prod_finish'),
            'ibees_crm_quantity': post.get('ibees_crm_quantity'),
            'ibees_crm_sku': post.get('ibees_crm_sku'),
            'ibees_crm_date': post.get('ibees_crm_date'),
            'name': name_u,
            'phone': post.get('mobile'),
            'email_from': post.get('email_from'),
            'description': post.get('description'),
            'ibees_crm_sample': post.get('ibees_crm_sample'),
            'type': lead_type,
            # 'file': post.get('y4jjmlxaeq'),

        }
        lead = request.env['crm.lead'].sudo().create(crm)
        if lead:
            return "true"
        else:
            return "false"

        # Return the HTML response directly with the conditional div

        # return request.render("ibees_base_portal.quotation_form_success")

    @http.route(['/website_form_submit'], type='http', auth="public", website=True, csrf=False)
    def form_contactus(self, **post):
        user = request.env.user
        val = request.env['ir.config_parameter'].sudo().get_param('group_use_lead')
        lead_type = 'lead' if val == 'True' else 'opportunity'
        if user and user.partner_id:
            name_u = user.partner_id.name
        else:
            name_u = post.get('contact_name')
        # desc = """
        #        Other Information: \n
        #        ___________\n
        #        Company: {}\n
        #        Subject: {}\n
        #        Email To: {}
        #        """.format(post.get('company'), post.get('subject'), post.get('email_from'))
        contact_us = {
            'name': name_u,
            'phone': post.get('phone'),
            'email_from': post.get('email_from'),
            'description': post.get('description'),
            'partner_name': post.get('company'),
            'ibees_crm_notepce': post.get('subject'),
            'type': lead_type,
            # 'file': post.get('y4jjmlxaeq'),
        }
        request.env['crm.lead'].sudo().create(contact_us)
        # form_data = request.env['crm.lead'].sudo().create(contact_us)
        # if form_data:
        #     return "true"
        # else:
        #     return "false"

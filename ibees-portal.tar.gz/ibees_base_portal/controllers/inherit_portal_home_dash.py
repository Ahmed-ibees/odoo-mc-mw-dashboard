# Part of Odoo. See LICENSE file for full copyright and licensing details.

import base64
import json
import logging
import math
import re

from werkzeug import urls

from odoo import SUPERUSER_ID, _, http, tools
from odoo.exceptions import (
    AccessDenied,
    AccessError,
    MissingError,
    UserError,
    ValidationError,
)
from odoo.http import content_disposition, request, route
from odoo.tools import consteq

from odoo.addons.portal.controllers.portal import CustomerPortal

# --------------------------------------------------
# Misc tools
# --------------------------------------------------

_logger = logging.getLogger(__name__)

class CustomerPortal(CustomerPortal):

    @route(["/my", "/my/test"], type="http", auth="user", website=True)
    def home(self, **kw):
        values = self._prepare_portal_layout_values()
        return request.render("ibees_base_portal.frontend_layout", values)


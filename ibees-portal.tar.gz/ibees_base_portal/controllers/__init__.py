from . import inherit_portal_crm
from . import inherit_portal_home_dash
# from . import inherit_sale_portal
# from . import inherit_invoice_portal
from . import inherit_portal_new_crm_rfq

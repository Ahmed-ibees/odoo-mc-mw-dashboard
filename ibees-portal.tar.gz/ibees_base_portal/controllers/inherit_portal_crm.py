# Part of Odoo. See LICENSE file for full copyright and licensing details.
from collections import OrderedDict

from odoo import fields, http
from odoo.exceptions import AccessError, MissingError
from odoo.http import request, route
from odoo.osv import expression
from odoo.tools.translate import _
from odoo.addons.account.controllers.download_docs import _get_zip_headers

from odoo.addons.portal.controllers.mail import _message_post_helper
from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager


# from werkzeug.exceptions import NotFound


class CustomerPortalCRM(CustomerPortal):
    def get_domain_my_rfq(self, user):
        return [
            ("partner_assigned_id", "child_of", user.commercial_partner_id.id),
            ("type", "=", "opportunity"),
        ]

    def _prepare_home_portal_values(self, counters):
        values = super()._prepare_home_portal_values(counters)
        if "opp_count" in counters:
            values["opp_count"] = request.env["crm.lead"].search_count(
                self.get_domain_my_rfq(request.env.user)
            )
        return values

    def _rfq_get_page_view_values(self, rfq, access_token, **kwargs):
        values = {"page_name": "RFQs", "rfq": rfq, "user": request.env.user}
        return self._get_page_view_values(
            rfq, access_token, values, "my_rfq_history", False, **kwargs
        )

    def _get_searchbar_inputs(self):
        return {
            "name": {"input": "name", "label": _("Search in Title")},
            "medium_id": {"input": "medium_id", "label": _("Search in Source")},
        }

    def _get_search_domain(self, search_in, search):
        search_domain = []
        if search_in in ("name"):
            search_domain = [("name", "ilike", search)]
        if search_in in ("medium_id"):
            search_domain = [("medium_id", "ilike", search)]
        return search_domain

    # @http.route(["/my/crm-rfqs", "/my/crm-rfqs/page/<int:page>"], type="http", auth="user", website=True)
    # def portal_my_rfqs(
    #         self,
    #         page=1,
    #         date_begin=None,
    #         date_end=None,
    #         sortby=None,
    #         filterby=None,
    #         search=None,
    #         search_in="name",
    #         **kw
    # ):
    #     values = self._prepare_portal_layout_values()
    #     CrmLead = request.env["crm.lead"]
    #     partner = request.env.user.partner_id
    #     domain = [("partner_id", "child_of", [partner.commercial_partner_id.id])]
    #     searchbar_filters = {
    #         "active": {"label": _("Active"), "domain": [("active", "=", True)]},
    #         "archived": {"label": _("Archived"), "domain": [("active", "=", False)]},
    #     }
    #     searchbar_sortings = {
    #         "date_new": {"label": _("Newest"), "order": "create_date desc"},
    #         "date_old": {"label": _("Oldest"), "order": "create_date asc"},
    #         "rfq_ref": {"label": _("Reference"), "order": "rfq_ref"},
    #         "rfq_status": {"label": _("Status"), "order": "rfq_status desc"},
    #     }
    #
    #     # default sort by value
    #     if not sortby:
    #         sortby = "date_new"
    #     order = searchbar_sortings[sortby]["order"]
    #     # Search bar
    #     searchbar_inputs = self._get_searchbar_inputs()
    #
    #     if search and search_in:
    #         domain += self._get_search_domain(search_in, search)
    #
    #     # default filter by value
    #     if not filterby:
    #         filterby = "active"
    #     domain += searchbar_filters[filterby]["domain"]
    #     # if filterby == "archived":
    #     #     CrmLead = CrmLead.with_context(active_test=False)
    #
    #     if date_begin and date_end:
    #         domain += [
    #             ("create_date", ">", date_begin),
    #             ("create_date", "<=", date_end),
    #         ]
    #     # pager
    #     _items_per_page = 15
    #     opp_count = CrmLead.search_count(domain)
    #     pager = portal_pager(
    #         url="/my/crm-rfqs",
    #         url_args={
    #             "date_begin": date_begin,
    #             "date_end": date_end,
    #             "sortby": sortby,
    #             "filterby": filterby,
    #         },
    #         total=opp_count,
    #         page=page,
    #         step=_items_per_page,
    #     )
    #     # content according to pager
    #     rfqs = CrmLead.search(
    #         domain, order=order, limit=_items_per_page, offset=pager["offset"]
    #     )
    #     request.session["my_rfq_history"] = rfqs.ids[:100]
    #
    #     values.update(
    #         {
    #             "date": date_begin,
    #             "rfqs": rfqs.sudo(),
    #             "page_name": "RFQs",
    #             "default_url": "/my/crm-rfqs",
    #             "pager": pager,
    #             "searchbar_sortings": searchbar_sortings,
    #             "search_in": search_in,
    #             "search": search,
    #             "sortby": sortby,
    #             "searchbar_inputs": searchbar_inputs,
    #             "searchbar_filters": OrderedDict(searchbar_filters.items()),
    #             "filterby": filterby,
    #         }
    #     )
    #     return request.render("ibees_base_portal.portal_rfq_template", values)
    # @http.route(
    #     ["/my/crm-rfqs", "/my/crm-rfqs/page/<int:page>"], type="http", auth="user", website=True
    # )
    # def portal_my_rfqs(
    #         self,
    #         page=1,
    #         date_begin=None,
    #         date_end=None,
    #         sortby=None,
    #         filterby=None,
    #         search=None,
    #         search_in="name",
    #         **kw
    # ):
    #     values = self._prepare_portal_layout_values()
    #     CrmLead = request.env["crm.lead"]
    #     partner = request.env.user.partner_id
    #     domain = [
    #         ("type", "=", "lead"),
    #         ("partner_id", "child_of", [partner.commercial_partner_id.id])
    #     ]
    #
    #     searchbar_filters = {
    #         "active": {"label": _("Active"), "domain": [("active", "=", True)]},
    #         "archived": {"label": _("Archived"), "domain": [("active", "=", False)]},
    #     }
    #     searchbar_sortings = {
    #         "date_new": {"label": _("Newest"), "order": "create_date desc"},
    #         "date_old": {"label": _("Oldest"), "order": "create_date asc"},
    #         "rfq_ref": {"label": _("Reference"), "order": "rfq_ref"},
    #         "rfq_status": {"label": _("Status"), "order": "rfq_status desc"},
    #     }
    #
    #     # default sort by value
    #     if not sortby:
    #         sortby = "date_new"
    #     order = searchbar_sortings[sortby]["order"]
    #     # Search bar
    #     searchbar_inputs = self._get_searchbar_inputs()
    #
    #     if search and search_in:
    #         domain += self._get_search_domain(search_in, search)
    #
    #     # default filter by value
    #     if not filterby:
    #         filterby = "active"
    #     domain += searchbar_filters[filterby]["domain"]
    #
    #     if date_begin and date_end:
    #         domain += [
    #             ("create_date", ">", date_begin),
    #             ("create_date", "<=", date_end),
    #         ]
    #     # pager
    #     _items_per_page = 15
    #     opp_count = CrmLead.search_count(domain)
    #     pager = portal_pager(
    #         url="/my/crm-rfqs",
    #         url_args={
    #             "date_begin": date_begin,
    #             "date_end": date_end,
    #             "sortby": sortby,
    #             "filterby": filterby,
    #         },
    #         total=opp_count,
    #         page=page,
    #         step=_items_per_page,
    #     )
    #     # content according to pager
    #     rfqs = CrmLead.search(
    #         domain, order=order, limit=_items_per_page, offset=pager["offset"]
    #     )
    #     request.session["my_rfq_history"] = rfqs.ids[:100]
    #
    #     values.update(
    #         {
    #             "date": date_begin,
    #             "rfqs": rfqs.sudo(),
    #             "page_name": "RFQs",
    #             "default_url": "/my/crm-rfqs",
    #             "pager": pager,
    #             "searchbar_sortings": searchbar_sortings,
    #             "search_in": search_in,
    #             "search": search,
    #             "sortby": sortby,
    #             "searchbar_inputs": searchbar_inputs,
    #             "searchbar_filters": OrderedDict(searchbar_filters.items()),
    #             "filterby": filterby,
    #         }
    #     )
    #     return request.render("ibees_base_portal.portal_rfq_template", values)
    @http.route(
        ["/my/crm-rfqs", "/my/crm-rfqs/page/<int:page>"], type="http", auth="user", website=True
    )
    def portal_my_rfqs(
            self,
            page=1,
            date_begin=None,
            date_end=None,
            sortby=None,
            filterby=None,
            search=None,
            search_in="name",
            **kw
    ):
        values = self._prepare_portal_layout_values()
        CrmLead = request.env["crm.lead"]

        # Search bar sorting options
        searchbar_sortings = {
            "date_new": {"label": _("Newest"), "order": "create_date desc"},
            "date_old": {"label": _("Oldest"), "order": "create_date asc"},
            "medium_id": {"label": _("Reference"), "order": "medium_id"},
            "name": {"label": _("Status"), "order": "name desc"},
        }

        # Default sorting
        if not sortby:
            sortby = "date_new"
        order = searchbar_sortings[sortby]["order"]

        # Search bar inputs
        searchbar_inputs = self._get_searchbar_inputs()

        # If search criteria provided
        if search and search_in:
            domain = self._get_search_domain(search_in, search)
        else:
            domain = []

        # Total count of leads
        opp_count = CrmLead.search_count(domain)

        # Pagination
        _items_per_page = 15
        pager = portal_pager(
            url="/my/crm-rfqs",
            url_args={
                "date_begin": date_begin,
                "date_end": date_end,
                "sortby": sortby,
                "filterby": filterby,
            },
            total=opp_count,
            page=page,
            step=_items_per_page,
        )

        # Fetching leads without domain filtering
        rfqs = CrmLead.search([], order=order, limit=_items_per_page, offset=pager["offset"])
        request.session["my_rfq_history"] = rfqs.ids[:100]

        values.update(
            {
                "date": date_begin,
                "rfqs": rfqs.sudo(),
                "page_name": "RFQs",
                "default_url": "/my/crm-rfqs",
                "pager": pager,
                "searchbar_sortings": searchbar_sortings,
                "search_in": search_in,
                "search": search,
                "sortby": sortby,
                "searchbar_inputs": searchbar_inputs,
                "filterby": filterby,
            }
        )
        return request.render("ibees_base_portal.portal_rfq_template", values)

    @http.route(
        ["/my/crm-rfq/<int:rfq_id>"],
        type="http",
        auth="public",
        website=True,
        sitemap=False,
    )
    def portal_my_rfq(self, rfq_id, access_token=None, message=None, **kw):
        try:
            rfq = self._document_check_access(
                "crm.lead", rfq_id, access_token=access_token
            )
        except (AccessError, MissingError):
            return request.redirect("/web/login")

        if rfq:
            # store the date as a string in the session to allow serialization
            now = fields.Date.today().isoformat()
            session_obj_date = request.session.get("view_quote_%s" % rfq.id)
            if session_obj_date != now and request.env.user.share and access_token:
                request.session["view_quote_%s" % rfq.id] = now
                body = _("RFQ viewed by customer %s", rfq.partner_id.name)
                _message_post_helper(
                    "crm.lead",
                    rfq.id,
                    body,
                    token=rfq.access_token,
                    message_type="notification",
                    subtype_xmlid="mail.mt_note",
                    partner_ids=rfq.user_id.sudo().partner_id.ids,
                )

        values = self._rfq_get_page_view_values(rfq, access_token, **kw)
        values.update(
            {
                "message": message,
                "states": request.env["res.country.state"].sudo().search([]),
                "countries": request.env["res.country"].sudo().search([]),
                "stages": request.env["crm.stage"].search(
                    # [("is_won", "!=", True), ("is_external_stage", "!=", False)],
                    [("is_won", "!=", True)],
                    order="sequence desc, name desc, id desc",  # noqa: B950
                ),
                # "rfq_medias": request.env['rfq.media'].sudo().search([]),
            }
        )
        return request.render("ibees_base_portal.rfq_portal_layout", values)

    @http.route('/portal/leads', auth='user', website=True)
    def portal_leads(self, **kw):
        leads = request.env['crm.lead'].search([])
        stages = request.env['crm.stage'].sudo().search([])  # Assuming all stages
        return http.request.render('ibees_base_portal.account_info', {
            'leads': leads,
            'stages': stages,
        })


    # @http.route(
    #     ["""/my/rfq/<model('crm.lead', "[('type','=', 'opportunity')]"):opp>"""],
    #     type="http",
    #     auth="user",
    #     website=True,
    # )
    # def portal_my_opportunity(self, opp, **kw):
    #     if opp.type != "opportunity":
    #         raise NotFound()

    #     return request.render(
    #         "ibees_base_portal.portal_my_rfq",
    #         {
    #             "rfq": opp,
    #             "user_activity": opp.sudo().activity_ids.filtered(
    #                 lambda activity: activity.user_id == request.env.user
    #             )[:1],
    #             "stages": request.env["crm.stage"].search(
    #                 [("is_won", "!=", True)], order="sequence desc, name desc, id desc" # noqa: B950
    #             ),
    #             "activity_types": request.env["mail.activity.type"].sudo().search([]),
    #             "states": request.env["res.country.state"].sudo().search([]),
    #             "countries": request.env["res.country"].sudo().search([]),
    #         },
    #     )
    @http.route(["/my/contactus"], type="http", auth="user", website=True)
    def contactus_template(self, **kwargs):
        return request.render("ibees_base_portal.contactus_template")

    @http.route(["/my/quote"], type="http", auth="user", website=True)
    def sales_order_layout(self, **kwargs):
        values = self._prepare_sale_portal_rendering_values(quotation_page=False, **kwargs)
        request.session['my_orders_history'] = values['orders'].ids[:100]
        return request.render("ibees_base_portal.sales_order_layout", values)

    @http.route(['/my/orders/<int:order_id>'], type='http', auth="public", website=True)
    def portal_order_page(
            self,
            order_id,
            report_type=None,
            access_token=None,
            message=False,
            download=False,
            downpayment=None,
            **kw
    ):
        try:
            order_sudo = self._document_check_access('sale.order', order_id, access_token=access_token)
        except (AccessError, MissingError):
            return request.redirect('/my')

        if report_type in ('html', 'pdf', 'text'):
            return self._show_report(
                model=order_sudo,
                report_type=report_type,
                report_ref='sale.action_report_saleorder',
                download=download,
            )

        if request.env.user.share and access_token:
            # If a public/portal user accesses the order with the access token
            # Log a note on the chatter.
            today = fields.Date.today().isoformat()
            session_obj_date = request.session.get('view_quote_%s' % order_sudo.id)
            if session_obj_date != today:
                # store the date as a string in the session to allow serialization
                request.session['view_quote_%s' % order_sudo.id] = today
                # The "Quotation viewed by customer" log note is an information
                # dedicated to the salesman and shouldn't be translated in the customer/website lgg
                context = {'lang': order_sudo.user_id.partner_id.lang or order_sudo.company_id.partner_id.lang}
                msg = _('Quotation viewed by customer %s',
                        order_sudo.partner_id.name if request.env.user._is_public() else request.env.user.partner_id.name)
                del context
                _message_post_helper(
                    "sale.order",
                    order_sudo.id,
                    message=msg,
                    token=order_sudo.access_token,
                    message_type="notification",
                    subtype_xmlid="mail.mt_note",
                    partner_ids=order_sudo.user_id.sudo().partner_id.ids,
                )

        backend_url = f'/web#model={order_sudo._name}' \
                      f'&id={order_sudo.id}' \
                      f'&action={order_sudo._get_portal_return_action().id}' \
                      f'&view_type=form'
        values = {
            'sale_order': order_sudo,
            'product_documents': order_sudo._get_product_documents(),
            'message': message,
            'report_type': 'html',
            'backend_url': backend_url,
            'res_company': order_sudo.company_id,  # Used to display correct company logo
        }

        # Payment values
        if order_sudo._has_to_be_paid():
            values.update(
                self._get_payment_values(
                    order_sudo,
                    downpayment=downpayment == 'true' if downpayment is not None else order_sudo.prepayment_percent < 1.0
                )
            )

        if order_sudo.state in ('draft', 'sent', 'cancel'):
            history_session_key = 'my_quotations_history'
        else:
            history_session_key = 'my_orders_history'

        values = self._get_page_view_values(
            order_sudo, access_token, values, history_session_key, False)

        return request.render('ibees_base_portal.sales_order_main', values)

    @http.route(["/my/invoices"], type="http", auth="user", website=True)
    def portal_invoices(self, page=1, date_begin=None, date_end=None, sortby=None, filterby=None, **kw):
        values = self._prepare_my_invoices_values(page, date_begin, date_end, sortby, filterby)
        pager = portal_pager(**values['pager'])

        # content according to pager and archive selected
        invoices = values['invoices'](pager['offset'])
        request.session['my_invoices_history'] = invoices.ids[:100]

        values.update({
            'invoices': invoices,
            'pager': pager,
        })
        return request.render("ibees_base_portal.portal_layout0", values)

    @http.route(['/my/invoices/<int:invoice_id>'], type='http', auth="public", website=True)
    def portal_my_invoice_detail(self, invoice_id, access_token=None, report_type=None, download=False, **kw):
        try:
            invoice_sudo = self._document_check_access('account.move', invoice_id, access_token)
        except (AccessError, MissingError):
            return request.redirect('/my')

        if report_type == 'pdf' and download and invoice_sudo.state == 'posted':
            # Send & Print wizard with only the 'download' checkbox to get the official attachment(s)
            template = request.env.ref(invoice_sudo._get_mail_template())
            attachment_ids = invoice_sudo._generate_pdf_and_send_invoice(template, bypass_download=True,
                                                                         checkbox_send_mail=False,
                                                                         checkbox_download=True)
            attachments = request.env['ir.attachment'].browse(attachment_ids)
            if len(attachments) > 1:
                filename = invoice_sudo._get_invoice_report_filename(extension='zip')
                zip_content = attachments.sudo()._build_zip_from_attachments()
                headers = _get_zip_headers(zip_content, filename)
                return request.make_response(zip_content, headers)
            headers = self._get_http_headers(invoice_sudo, report_type, attachments.raw, download)
            return request.make_response(attachments.raw, list(headers.items()))

        elif report_type in ('html', 'pdf', 'text'):
            return self._show_report(model=invoice_sudo, report_type=report_type, report_ref='account.account_invoices',
                                     download=download)

        values = self._invoice_get_page_view_values(invoice_sudo, access_token, **kw)
        return request.render("ibees_base_portal.invoice_main_pages", values)

    @http.route(["/my/tickets"], type="http", auth="user", website=True)
    def help_desk_layout(self, **kw):
        return request.render("ibees_base_portal.help_desk_layout")

    @route(['/my/accounts'], type='http', auth='user', website=True)
    def account(self, redirect=None, **post):
        values = self._prepare_portal_layout_values()
        partner = request.env.user.partner_id
        values.update({
            'error': {},
            'error_message': [],
        })

        if post and request.httprequest.method == 'POST':
            error, error_message = self.details_form_validate(post)
            values.update({'error': error, 'error_message': error_message})
            values.update(post)
            if not error:
                values = {key: post[key] for key in self._get_mandatory_fields()}
                values.update({key: post[key] for key in self._get_optional_fields() if key in post})
                for field in set(['country_id', 'state_id']) & set(values.keys()):
                    try:
                        values[field] = int(values[field])
                    except:
                        values[field] = False
                values.update({'zip': values.pop('zipcode', '')})
                self.on_account_update(values, partner)
                partner.sudo().write(values)
                if redirect:
                    return request.redirect(redirect)
                return request.redirect('/my/test')

        countries = request.env['res.country'].sudo().search([])
        states = request.env['res.country.state'].sudo().search([])

        values.update({
            'partner': partner,
            'countries': countries,
            'states': states,
            'has_check_vat': hasattr(request.env['res.partner'], 'check_vat'),
            'partner_can_edit_vat': partner.can_edit_vat(),
            'redirect': redirect,
            'page_name': 'my_details',
        })

        response = request.render("ibees_base_portal.account_info", values)
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['Content-Security-Policy'] = "frame-ancestors 'self'"
        return response

    def on_account_update(self, values, partner):
        pass

    @http.route(["/my/security"], type='http', auth='user', website=True, methods=['GET', 'POST'])
    def login_security_portal(self, **post):
        # return request.render("ibees_base_portal.login_security_portal")
        values = self._prepare_portal_layout_values()
        values['get_error'] = get_error
        values['allow_api_keys'] = bool(request.env['ir.config_parameter'].sudo().get_param('portal.allow_api_keys'))
        values['open_deactivate_modal'] = False

        if request.httprequest.method == 'POST':
            values.update(self._update_password(
                post['old'].strip(),
                post['new1'].strip(),
                post['new2'].strip()
            ))

        return request.render('ibees_base_portal.login_security_portal', values, headers={
            'X-Frame-Options': 'SAMEORIGIN',
            'Content-Security-Policy': "frame-ancestors 'self'"
        })

        # def get_page_title(self):
        #     page_title = request.env['ir.ui.view'].browse(request.env.ref('ibees_base_portal.view_id').id).name
        #     return page_title


def get_error(e, path=''):
    """ Recursively dereferences `path` (a period-separated sequence of dict
    keys) in `e` (an error dict or value), returns the final resolution IIF it's
    an str, otherwise returns None
    """
    for k in (path.split('.') if path else []):
        if not isinstance(e, dict):
            return None
        e = e.get(k)

    return e if isinstance(e, str) else None
